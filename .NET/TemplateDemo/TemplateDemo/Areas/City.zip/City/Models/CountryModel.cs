﻿namespace TemplateDemo.Areas.City.Models
{
    public class CountryModel
    {
        public int CountryID { get; set; }
        public string CountryName { get; set; }
    }
}
