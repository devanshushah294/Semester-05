﻿namespace TemplateDemo.Areas.City.Models
{
    public class StateModel
    {
        public int StateID { get; set; }
        public string StateName{ get; set; }
        public int CountryID { get; set; }
    }
}
