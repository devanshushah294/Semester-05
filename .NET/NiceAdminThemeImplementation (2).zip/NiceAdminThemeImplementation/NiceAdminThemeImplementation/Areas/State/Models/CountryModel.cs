﻿namespace NiceAdminThemeImplementation.Areas.State.Models
{
    public class CountryModel
    {
        public int CountryId { get; set; }
        public string CountryName { get; set; } = string.Empty;
    }
}
