﻿namespace NiceAdminThemeImplementation.Areas.Student.Models
{
    public class BranchModel
    {
        public int BranchID { get; set; }
        public string BranchName { get; set; } = string.Empty;
    }
}
